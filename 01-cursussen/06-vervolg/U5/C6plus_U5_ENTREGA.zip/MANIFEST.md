# C6+ · vervolgcursus 6de jaar (huidige cohorte) — leverings-zip

**Gebouwd op:** 04/08/2026 22:27
**Units in deze zip:** U5
**Bestanden:** 6

> Deze zip is een **momentopname** van de bestanden op het moment hierboven.
> Wordt een hub, PDF of PowerPoint later opnieuw gegenereerd, maak dan een
> nieuwe zip met `python3 03-build/make_zip.py C6+`.

## Inhoud per unit

**U5**
- `C6plus_U5.pdf`
- `C6plus_U5_BEWERKBAAR.html`
- `C6plus_U5_alumno.pptx`
- `C6plus_U5_docente.pptx`
- `C6plus_U5_hub.html`
- `LEESMIJ.md`

## De formaten

| Bestand | Wat |
|---|---|
| `*.pdf` | print-klaar, om af te drukken |
| `*_BEWERKBAAR.html` | dezelfde cursus, wél bewerkbaar (open in de browser, pas aan, «Opslaan als PDF») |
| `*_hub.html` | de digitale pagina: audio, flip cards, oefeningen en de motor-spellen — werkt offline |
| `*_docente.pptx` | PowerPoint voor de klas (met oplossingen) |
| `*_alumno.pptx` | leerlingversie (F5 voor de diavoorstelling) |
