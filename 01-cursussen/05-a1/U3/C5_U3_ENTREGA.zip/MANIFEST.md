# C5 · «Español en la práctica» — kerncursus 5de jaar — leverings-zip

**Gebouwd op:** 01/08/2026 23:39
**Units in deze zip:** U3
**Bestanden:** 6

> Deze zip is een **momentopname** van de bestanden op het moment hierboven.
> Wordt een hub, PDF of PowerPoint later opnieuw gegenereerd, maak dan een
> nieuwe zip met `python3 03-build/make_zip.py C5`.

## Inhoud per unit

**U3**
- `C5_U3.pdf`
- `C5_U3_BEWERKBAAR.html`
- `C5_U3_alumno.pptx`
- `C5_U3_docente.pptx`
- `C5_U3_hub.html`
- `LEESMIJ.md`

## De formaten

| Bestand | Wat |
|---|---|
| `*.pdf` | print-klaar, om af te drukken |
| `*_BEWERKBAAR.html` | dezelfde cursus, wél bewerkbaar (open in de browser, pas aan, «Opslaan als PDF») |
| `*_hub.html` | de digitale pagina: audio, flip cards, oefeningen en de motor-spellen — werkt offline |
| `*_docente.pptx` | PowerPoint voor de klas (met oplossingen) |
| `*_alumno.pptx` | leerlingversie (F5 voor de diavoorstelling) |
