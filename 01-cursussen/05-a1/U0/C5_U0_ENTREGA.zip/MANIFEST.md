# C5 · «Español en la práctica» — kerncursus 5de jaar — leverings-zip

**Gebouwd op:** 02/08/2026 19:27
**Units in deze zip:** U0
**Bestanden:** 6

> Deze zip is een **momentopname** van de bestanden op het moment hierboven.
> Wordt een hub, PDF of PowerPoint later opnieuw gegenereerd, maak dan een
> nieuwe zip met `python3 03-build/make_zip.py C5`.

## Inhoud per unit

**U0**
- `C5_U0.pdf`
- `C5_U0_BEWERKBAAR.html`
- `C5_U0_alumno.pptx`
- `C5_U0_docente.pptx`
- `C5_U0_hub.html`
- `LEESMIJ.md`

## De formaten

| Bestand | Wat |
|---|---|
| `*.pdf` | print-klaar, om af te drukken |
| `*_BEWERKBAAR.html` | dezelfde cursus, wél bewerkbaar (open in de browser, pas aan, «Opslaan als PDF») |
| `*_hub.html` | de digitale pagina: audio, flip cards, oefeningen en de motor-spellen — werkt offline |
| `*_docente.pptx` | PowerPoint voor de klas (met oplossingen) |
| `*_alumno.pptx` | leerlingversie (F5 voor de diavoorstelling) |
